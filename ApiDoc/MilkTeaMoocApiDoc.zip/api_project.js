define({
  "name": "Milk Tea Mooc",
  "version": "0.1.0",
  "description": "The API Document of MilkTea online learning website",
  "title": "Milk Tea Mooc API Document",
  "url": "https://milktea.wuyuling.net/",
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2020-09-08T06:15:37.042Z",
    "url": "https://apidocjs.com",
    "version": "0.25.0"
  }
});
