define({ "api": [
  {
    "success": {
      "fields": {
        "Success 200": [
          {
            "group": "Success 200",
            "optional": false,
            "field": "varname1",
            "description": "<p>No type.</p>"
          },
          {
            "group": "Success 200",
            "type": "String",
            "optional": false,
            "field": "varname2",
            "description": "<p>With type.</p>"
          }
        ]
      }
    },
    "type": "",
    "url": "",
    "version": "0.0.0",
    "filename": "./ApiDoc/main.js",
    "group": "F:\\Back-end Learning\\SSM-projects\\milkteamooc\\ApiDoc\\main.js",
    "groupTitle": "F:\\Back-end Learning\\SSM-projects\\milkteamooc\\ApiDoc\\main.js",
    "name": ""
  },
  {
    "type": "post",
    "url": "api/v1/pri/user/login",
    "title": "User Login Interface",
    "name": "login",
    "group": "User",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "userInfo",
            "description": "<p>Login Phone and Password.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request Example:",
          "content": "{\n\"phone\": \"123456\",\n\"pwd\": \"123456\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"code\": 0,\n\"data\": \"Token String\",\n\"msg\": null\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "{\n\"code\": -1,\n\"data\": null,\n\"msg\": \"Login Failed, Wrong User Information\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./src/main/java/net/wuyuling/milkteamooc/controller/UserController.java",
    "groupTitle": "User"
  },
  {
    "type": "post",
    "url": "api/v1/pri/user/register",
    "title": "Sign up a new user by Unique Phone Number",
    "name": "register",
    "group": "User",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "userInfo",
            "description": "<p>the User's Information</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request Example:",
          "content": "{\n\"phone\": \"123456\",\n\"name\": \"testMilkTea\",\n\"pwd\": \"123456\"\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"code\": 0,\n\"data\": null,\n\"msg\": null\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "{\n\"code\": -1,\n\"data\": null,\n\"msg\": \"The phone has already registered\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./src/main/java/net/wuyuling/milkteamooc/controller/UserController.java",
    "groupTitle": "User"
  },
  {
    "type": "get",
    "url": "api/v1/pri/order/list",
    "title": "List All Order Records of a specific User",
    "name": "listOrder",
    "group": "VideoOrder",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "header",
            "optional": false,
            "field": "token",
            "description": "<p>The Login Token.</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"code\": 0,\n\"data\": [\n{\n\"id\": 14,\n\"outTradeNo\": \"1765cc94-caf6-4eb3-9127-26310c32ae35\",\n\"state\": 1,\n\"createTime\": \"2020-09-07 22:08:19\",\n\"totalFee\": 5980,\n\"videoId\": 42,\n\"videoTitle\": \"videoTitle\",\n\"videoImg\": \"https://xd-video-pc-img.oss-cn-beijing.aliyuncs.com/xdclass_pro/video/2019_frontend/element/elementui.png\",\n\"userId\": 11\n}\n],\n\"msg\": null\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./src/main/java/net/wuyuling/milkteamooc/controller/VideoOrderController.java",
    "groupTitle": "VideoOrder"
  },
  {
    "type": "post",
    "url": "api/v1/pri/order/save",
    "title": "Save the User's purchase record",
    "name": "saveOrder",
    "group": "VideoOrder",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "header",
            "optional": false,
            "field": "token",
            "description": "<p>The Login Token.</p>"
          },
          {
            "group": "Parameter",
            "type": "json",
            "optional": false,
            "field": "videoOrderRequest",
            "description": "<p>The Video Order Info.</p>"
          }
        ]
      },
      "examples": [
        {
          "title": "Request Example:",
          "content": "{\n\"video_id\" : 34\n}",
          "type": "json"
        }
      ]
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"code\": 0,\n\"data\": null,\n\"msg\": null\n}",
          "type": "json"
        }
      ]
    },
    "error": {
      "examples": [
        {
          "title": "Error-Response:",
          "content": "{\n\"code\": -1,\n\"data\": null,\n\"msg\": \"Oops! Purchase Failed\"\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./src/main/java/net/wuyuling/milkteamooc/controller/VideoOrderController.java",
    "groupTitle": "VideoOrder"
  },
  {
    "type": "get",
    "url": "api/v1/pub/video/find_detail_by_id?video_id=id",
    "title": "Query video details, including chapter and episode info",
    "name": "findDetailById",
    "group": "Video",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "type": "Number",
            "optional": false,
            "field": "videoId",
            "description": "<p>The specified Video ID (required, send as a parameter).</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"code\": 0,\n\"data\": {\n\"id\": 44,\n\"title\": \"title\",\n\"summary\": \"https://xd-video-pc-img.oss-cn-beijing.aliyuncs.com/xdclass_pro/video/jdk8/jdk8_detail.png\",\n\"coverImg\": \"https://xd-video-pc-img.oss-cn-beijing.aliyuncs.com/xdclass_pro/video/jdk8/jdk8.png\",\n\"price\": 3980,\n\"createTime\": \"2019-10-10 14:14:00\",\n\"point\": 9.3,\n\"chapterList\": [\n{\n\"id\": 510,\n\"videoId\": null,\n\"title\": \"chapterTitle\",\n\"ordered\": 1,\n\"createTime\": null,\n\"episodeList\": [\n{\n\"id\": 12101,\n\"title\": \"chapterTitle\",\n\"num\": 1,\n\"ordered\": 1,\n\"playUrl\": \"xdclass.net/aaa.mp4\",\n\"chapterId\": null,\n\"free\": 0,\n\"videoId\": null,\n\"createTime\": null\n},\n{\n\"id\": 12102,\n\"title\": \"chapterTitle\",\n\"num\": 2,\n\"ordered\": 2,\n\"playUrl\": \"xdclass.net/aaa.mp4\",\n\"chapterId\": null,\n\"free\": 0,\n\"videoId\": null,\n\"createTime\": null\n}\n]\n}\n]\n},\n\"msg\": null\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./src/main/java/net/wuyuling/milkteamooc/controller/VideoController.java",
    "groupTitle": "Video"
  },
  {
    "type": "get",
    "url": "api/v1/pub/video/list_banner",
    "title": "List the Carousel List",
    "name": "indexBanner",
    "group": "Video",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "optional": false,
            "field": "null",
            "description": "<p>null</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"code\": 0,\n\"data\": [\n{\n\"id\": 1,\n\"url\": \"https://m.xdclass.net/#/coursedetail?video_id=49\",\n\"img\": \"https://file.xdclass.net/video/2020/%E9%9D%A2%E8%AF%95%E4%B8%93%E9%A2%98/%E9%9D%A2%E8%AF%95%E4%B8%93%E9%A2%98%E7%AC%AC%E4%B8%80%E5%AD%A3banner.png\",\n\"createTime\": null,\n\"weight\": 1\n},\n{\n\"id\": 2,\n\"url\": \"https://m.xdclass.net/#/member\",\n\"img\": \"https://file.xdclass.net/video/%E5%AE%98%E7%BD%91%E8%BD%AE%E6%92%AD%E5%9B%BE/%E8%BD%AE%E6%92%AD%E5%9B%BE-VIP.png\",\n\"createTime\": null,\n\"weight\": 2\n}\n],\n\"msg\": null\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./src/main/java/net/wuyuling/milkteamooc/controller/VideoController.java",
    "groupTitle": "Video"
  },
  {
    "type": "get",
    "url": "/api/v1/pub/video/list",
    "title": "List all the Videos",
    "name": "videoList",
    "group": "Video",
    "parameter": {
      "fields": {
        "Parameter": [
          {
            "group": "Parameter",
            "optional": false,
            "field": "null",
            "description": "<p>null</p>"
          }
        ]
      }
    },
    "success": {
      "examples": [
        {
          "title": "Success-Response:",
          "content": "{\n\"code\": 0,\n\"data\": [\n{\n\"id\": 30,\n\"title\": \"title\",\n\"summary\": \"https://xd-video-pc-img.oss-cn-beijing.aliyuncs.com/xdclass_pro/video/2019_backend/jvm_detail.jpeg\",\n\"coverImg\": \"https://xd-video-pc-img.oss-cn-beijing.aliyuncs.com/xdclass_pro/video/2019_backend/jvm.jpeg\",\n\"price\": 3980,\n\"createTime\": \"2019-06-24 14:14:00\",\n\"point\": 9.1,\n\"chapterList\": null\n},\n{\n\"id\": 31,\n\"title\": \"title\",\n\"summary\": \"https://xd-video-pc-img.oss-cn-beijing.aliyuncs.com/xdclass_pro/video/2019_backend/shiro_detail.jpeg\",\n\"coverImg\": \"https://xd-video-pc-img.oss-cn-beijing.aliyuncs.com/xdclass_pro/video/2019_backend/shiro.jpeg\",\n\"price\": 2980,\n\"createTime\": \"2019-06-24 14:14:00\",\n\"point\": 8.9,\n\"chapterList\": null\n}\n],\n\"msg\": null\n}",
          "type": "json"
        }
      ]
    },
    "version": "0.0.0",
    "filename": "./src/main/java/net/wuyuling/milkteamooc/controller/VideoController.java",
    "groupTitle": "Video"
  }
] });
